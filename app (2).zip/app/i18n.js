export const locales = ["fr", "en", "de"];
export const defaultLocale = "fr";
