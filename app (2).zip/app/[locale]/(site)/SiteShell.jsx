// app/[locale]/(site)/SiteShell.jsx (Client)
'use client';
import Navigation from '@/app/components/navigation/Navigation';
import { useNavData } from '@/app/providers/NavDataProvider';

export default function SiteShell({ children }) {
  const { nav, locale } = useNavData();
  return (
    <>
      <Navigation currentLocale={locale} nav={nav} />
      <div className="pt-40">{children}</div>
    </>
  );
}
