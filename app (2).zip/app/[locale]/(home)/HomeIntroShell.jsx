// app/[locale]/(home)/HomeIntroShell.jsx (Client)
'use client';
import { useEffect, useRef, useState } from 'react';
import { useNavData } from '@/app/providers/NavDataProvider';
import Navigation from '@/app/components/navigation/Navigation';
import LogoBarsWave from '@/app/components/LogoBarWave';

export default function HomeIntroShell({ children }) {
    const { nav, locale } = useNavData(); // ⬅️ récupère sans props/cloning
    const [showNav, setShowNav] = useState(false);
    const [showContent, setShowContent] = useState(false);
    const navRef = useRef(null);

    useEffect(() => {
        const el = navRef.current;
        if (!el) return;
        const onEnd = (e) => e.propertyName === 'opacity' && setShowContent(true);
        el.addEventListener('transitionend', onEnd);
        return () => el.removeEventListener('transitionend', onEnd);
    }, []);

    useEffect(() => {
        if (showNav && !showContent) {
            const id = setTimeout(() => setShowContent(true), 500);
            return () => clearTimeout(id);
        }
    }, [showNav, showContent]);

    return (
        <>
            <Navigation currentLocale={locale} nav={nav} />
            <LogoBarsWave
                src="/logo/MIAM.svg"
                height={200}
                paddingY={100}
                bars={140}
                amplitude={100}
                frequency={2}
                baseSpeed={1}
                introFreq={2}
                // intro
                introDuration={0}
                settleDuration={3000}
                introSpeed={0}
                introAmp={1}
                idleInfluence={0}
                hoverRadius={24}
                falloff={0.012}
                maxSpeed={8}
                accelRate={1}
                releaseRate={4}
                fit="contain"
                onIntroEnd={() => setShowNav(true)}
            />
            <section
                style={{
                    opacity: showContent ? 1 : 0,
                    transform: `translateY(${showContent ? 0 : 8}px)`,
                    transition: 'opacity 500ms ease, transform 500ms ease',
                    pointerEvents: showContent ? 'auto' : 'none',
                }}
            >
                {children}
            </section>
        </>
    );
}
