// app/[locale]/(home)/layout.jsx (Server)
import HomeIntroShell from './HomeIntroShell';
export default function HomeLayout({ children }) {
  return <HomeIntroShell>{children}</HomeIntroShell>;
}
