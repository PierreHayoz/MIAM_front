// app/[locale]/(home)/page.jsx  (server ok)
export const revalidate = 0;

export default async function HomePage() {
  return (
    <div className="px-4">
      <h1 className="text-3xl">Bienvenue</h1>
      <p>Le contenu s’affiche juste après la nav.</p>
      {/* … ton contenu home … */}
    </div>
  );
}
