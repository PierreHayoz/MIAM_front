'use client';
import React, { useEffect, useRef, useState } from 'react';

export default function LogoBarsWave({
  src,
  // dimensions
  height = 300,          // hauteur utile (hors marges)
  paddingY,              // marge haut/bas; par défaut = amplitude
  // rendu
  bars = 160,
  background = 'transparent',
  fit = 'contain',       // contain | cover | stretch
  // onde de base
  amplitude = 50,
  frequency = 0.02,
  baseSpeed = 1,
  // interaction
  introFreq = 0.5,
  hoverRadius = 200,
  falloff = 0.008,
  // maintien (appui) => accélération progressive
  maxSpeed = 3,
  accelRate = 1.2,       // montee vitesse en appui
  releaseRate = 0.2,     // descente vitesse au relâchement
  // PHASES d’intro
  introDuration = 0,  // ms — phase intense
  settleDuration = 3000, // ms — retour au calme
  introSpeed = 2.6,      // vitesse durant l’intro
  introAmp = 1.8,        // multiplicateur d’amplitude durant l’intro
  idleInfluence = 0.12,  // micro-mouvement une fois interactif (0 = totalement à l’arrêt)
  skipOnClick = false,    // clic = passer direct en interactif
  onPhaseChange,
  onIntroEnd,
}) {
  const padYProp = paddingY ?? amplitude;

  const canvasRef = useRef(null);
  const offscreenRef = useRef(null);
  const rafRef = useRef(null);
  const [img, setImg] = useState(null);

  // pointeur + lissages + vitesse
  const mouseRef = useRef({ x: 0, y: 0, inside: false, holding: false });
  const smoothRef = useRef({
    x: 0, y: 0,
    influence: 0, targetInfluence: 0,
    speed: baseSpeed, targetSpeed: baseSpeed,
  });
  const holdRef = useRef({ t: 0 });          // temps d’appui cumulé (monte/descend)
  const phaseRef = useRef({ name: 'intro', t0: performance.now() }); // intro | settle | interactive


  const firedIntroEndRef = useRef(false);
  const setPhase = (name) => {
    if (phaseRef.current.name !== name) {
      phaseRef.current.name = name;
      phaseRef.current.t0 = performance.now();
      if (typeof onPhaseChange === 'function') onPhaseChange(name);
      if (name === 'interactive' && !firedIntroEndRef.current) {
        firedIntroEndRef.current = true;
        if (typeof onIntroEnd === 'function') onIntroEnd();
      }
    }
  };

  // charge l'image
  useEffect(() => {
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.src = src;
    const onLoad = () => setImg(image);
    image.addEventListener('load', onLoad);
    return () => image.removeEventListener('load', onLoad);
  }, [src]);

  // offscreen (une fois)
  useEffect(() => {
    if (!offscreenRef.current) {
      offscreenRef.current = document.createElement('canvas');
    }
  }, []);

  // responsive largeur (100%)
  useEffect(() => {
    const canvas = canvasRef.current;
    const offscreen = offscreenRef.current;
    if (!canvas || !offscreen) return;

    function resize() {
      const dpr = window.devicePixelRatio || 1;
      const cssWidth = canvas.clientWidth || window.innerWidth;
      const cssHeight = height + 2 * padYProp;

      canvas.width = Math.round(cssWidth * dpr);
      canvas.height = Math.round(cssHeight * dpr);
      canvas.style.height = `${cssHeight}px`;

      offscreen.width = canvas.width;
      offscreen.height = canvas.height;
    }

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [height, padYProp]);

  // souris + maintenir
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const onMove = (e) => {
      const r = canvas.getBoundingClientRect();
      const sx = canvas.width / r.width;
      const sy = canvas.height / r.height;
      mouseRef.current.x = (e.clientX - r.left) * sx;
      mouseRef.current.y = (e.clientY - r.top) * sy;
    };
    const onEnter = () => {
      mouseRef.current.inside = true;
      if (phaseRef.current.name === 'interactive') {
        smoothRef.current.targetInfluence = 1; // hover ON
      }
    };
    const onLeave = () => {
      mouseRef.current.inside = false;
      mouseRef.current.holding = false;
      if (phaseRef.current.name === 'interactive') {
        smoothRef.current.targetInfluence = idleInfluence; // hover OFF → idle
      }
    };
    const onDown = () => {
  if (phaseRef.current.name === 'interactive') {
    mouseRef.current.holding = true;
  }
  if (skipOnClick && phaseRef.current.name !== 'interactive') {
    setPhase('interactive');                 // <-- déclenchera les callbacks
    smoothRef.current.targetInfluence = 1;
    holdRef.current.t = 0;
  }
};

    const onUp = () => {
      mouseRef.current.holding = false;
    };

    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerenter', onEnter);
    canvas.addEventListener('pointerleave', onLeave);
    canvas.addEventListener('pointerdown', onDown);
    window.addEventListener('pointerup', onUp);
    return () => {
      canvas.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('pointerenter', onEnter);
      canvas.removeEventListener('pointerleave', onLeave);
      canvas.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointerup', onUp);
    };
  }, [idleInfluence, skipOnClick]);

  // init vitesse
  useEffect(() => {
    smoothRef.current.speed = baseSpeed;
    smoothRef.current.targetSpeed = baseSpeed;
  }, [baseSpeed]);

  // animation principale
  useEffect(() => {
    const canvas = canvasRef.current;
    const offscreen = offscreenRef.current;
    if (!canvas || !offscreen) return;

    const ctx = canvas.getContext('2d');
    const octx = offscreen.getContext('2d');

    let last = performance.now();

    function drawLogoToOffscreen(totalW, totalH, dpr) {
      octx.setTransform(1, 0, 0, 1, 0, 0);
      if (background !== 'transparent') {
        octx.fillStyle = background;
        octx.fillRect(0, 0, totalW, totalH);
      } else {
        octx.clearRect(0, 0, totalW, totalH);
      }
      if (!img) return;

      const padY = Math.round(padYProp * dpr);
      const innerH = totalH - 2 * padY;

      const iw = img.naturalWidth || 1;
      const ih = img.naturalHeight || 1;
      let dw = totalW, dh = innerH, dx = 0, dy = padY;

      if (fit === 'contain') {
        const s = Math.min(totalW / iw, innerH / ih);
        dw = iw * s; dh = ih * s;
        dx = (totalW - dw) / 2;
        dy = padY + (innerH - dh) / 2;
      } else if (fit === 'cover') {
        const s = Math.max(totalW / iw, innerH / ih);
        dw = iw * s; dh = ih * s;
        dx = (totalW - dw) / 2;
        dy = padY + (innerH - dh) / 2;
      }
      octx.imageSmoothingEnabled = true;
      octx.imageSmoothingQuality = 'high';
      octx.drawImage(img, 0, 0, iw, ih, dx, dy, dw, dh);
    }

    const render = (now) => {
      rafRef.current = requestAnimationFrame(render);

      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      const dpr = window.devicePixelRatio || 1;
      const totalW = canvas.width;
      const totalH = canvas.height;
      const padY = Math.round(padYProp * dpr);
      const innerH = totalH - 2 * padY;

      if (img) drawLogoToOffscreen(totalW, totalH, dpr);

      // fond destination
      if (background !== 'transparent') {
        ctx.fillStyle = background;
        ctx.fillRect(0, 0, totalW, totalH);
      } else {
        ctx.clearRect(0, 0, totalW, totalH);
      }

      // =====================
      //      PHASES
      // =====================
      const S = smoothRef.current;
      const M = mouseRef.current;
      const ph = phaseRef.current;

      // temps dans les phases (ms)
      const sinceStart = performance.now() - ph.t0;
      const easeOut = (t) => 1 - Math.pow(1 - t, 3);            // outCubic
      const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

      let ampFactor = 1;    // multiplicateur d’amplitude
      let targetSpeed = baseSpeed;
      let targetInfluence = idleInfluence;
      let freqNow = frequency;
      if (ph.name === 'intro') {
        const p = Math.min(1, sinceStart / introDuration);
        ampFactor = 1 + (introAmp - 1) * easeOut(p);
        targetSpeed = baseSpeed + (introSpeed - baseSpeed) * easeOut(p);
        targetInfluence = 1;
        freqNow = introFreq;                   // <<--- fréquence boostée
        if (p >= 1) setPhase('settle');           // <-- au lieu d'assigner directement
      } else if (ph.name === 'settle') {
        const p = Math.min(1, sinceStart / settleDuration);
        ampFactor = 1 + (introAmp - 1) * (1 - easeInOut(p));
        targetSpeed = baseSpeed + (introSpeed - baseSpeed) * (1 - easeInOut(p));
        targetInfluence = idleInfluence + (1 - idleInfluence) * (1 - easeInOut(p));
        freqNow = introFreq + (frequency - introFreq) * easeInOut(p); // <<--- interpolation
        if (p >= 1) setPhase('interactive'); 
      } else {
        // interactive
        targetInfluence = M.inside ? 1 : idleInfluence;
        if (M.holding) holdRef.current.t += dt; else holdRef.current.t = Math.max(0, holdRef.current.t - dt * releaseRate);
        const progress = 1 - Math.exp(-accelRate * holdRef.current.t);
        targetSpeed = baseSpeed + (maxSpeed - baseSpeed) * progress;
        freqNow = frequency;                   // <<--- fréquence normale
      }


      // ====== LISSAGES généraux ======
      // souris lissée
      const mouseEase = 10;
      const aMouse = 1 - Math.exp(-mouseEase * dt);
      S.x += (M.x - S.x) * aMouse;
      S.y += (M.y - S.y) * aMouse;

      // influence lissée
      const hoverEase = 6;
      const aInf = 1 - Math.exp(-hoverEase * dt);
      S.targetInfluence = targetInfluence;
      S.influence += (S.targetInfluence - S.influence) * aInf;

      // vitesse lissée
      const speedEase = 3.5;
      const aSpeed = 1 - Math.exp(-speedEase * dt);
      S.targetSpeed = targetSpeed;
      S.speed += (S.targetSpeed - S.speed) * aSpeed;

      // ====== dessin des barres ======
      const barCount = Math.max(1, Math.floor(bars));
      const barW = totalW / barCount;

      // pendant l’intro, on veut une onde forte partout → on ignore la distance souris (fall = 1)
      const introLike = (ph.name === 'intro' || ph.name === 'settle');

      for (let i = 0; i < barCount; i++) {
        const sx = Math.round(i * barW);
        const sw = Math.ceil(barW);
        const dx = sx, dw = sw;

        let fall = 1;
        if (!introLike) {
          const distX = Math.abs(S.x - (sx + dw * 0.5));
          fall = Math.exp(-Math.max(0, distX - hoverRadius * dpr) * (falloff / dpr));
        }

        const phase = (now / 1000) * 3 * S.speed + i * freqNow * 10;
        const offset = Math.sin(phase) * (amplitude * ampFactor * dpr) * fall * S.influence;

        const sy = padY;
        const sh = innerH;
        const dy = Math.max(-padY, Math.min(padY, offset));

        ctx.drawImage(offscreen, sx, sy, sw, sh, dx, sy + dy, dw, sh);
      }
    };

    rafRef.current = requestAnimationFrame(render);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [
    img, bars, amplitude, frequency, baseSpeed, maxSpeed, accelRate, releaseRate,
    hoverRadius, falloff, background, fit, padYProp,
    introDuration, settleDuration, introSpeed, introAmp, idleInfluence
  ]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        display: 'block',
        width: '100%', // responsive en largeur
        height: `${height + 2 * padYProp}px`,
        cursor: 'pointer',
      }}
    />
  );
}
