import SvgMorphLayers from "@/components/SvgMorphLayers";

export default function Page() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Morphing par calque</h1>
      <SvgMorphLayers />
    </main>
  );
}
