export async function GET() {
  return new Response("pong");
}
