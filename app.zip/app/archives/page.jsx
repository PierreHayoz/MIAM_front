import Image from "next/image";
import CardsList from "../components/cards/CardsList";
import { getEvents } from "../lib/events";

const HOVER_BGS = [
    "bg-MIAMblack",
    "bg-MIAMviolet",
    "bg-MIAMtomato",
    "bg-MIAMlime",
];

// petit hash stable
function hashKey(key) {
    const s = String(key ?? "");
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return h >>> 0; // unsigned
}
function pickBg(key) {
    const idx = hashKey(key) % HOVER_BGS.length;
    return HOVER_BGS[idx];
}

export default async function Page() {
    const events = await getEvents();

    return (
        <section>
            <div className="grid grid-cols-4 px-4">
                <h2 className="text-3xl">Archives</h2>
                <div className="col-span-2 relative">
                    {events.map((event, idx) => {
                        const bg = pickBg(event.slug ?? event.id ?? idx);
                        // optionnel: ajuster le blend si fond noir
                        const imgBlend = bg === "bg-MIAMblack" ? "mix-blend-lighten invert" : "mix-blend-darken";

                        return (
                            <div key={event.slug ?? idx} className="border-b py-2 group relative" >
                                <div className="flex items-center">
                                    <span className="opacity-0 group-hover:opacity-100 absolute -left-8 group-hover:left-0 duration-500">→</span>
                                    <div className="cursor-pointer group-hover:translate-x-8  duration-500">{event.title}</div>
                                </div>
                                {/* image qui n'apparait que quand on hover le titre */}
                                <div
                                    className={`absolute top-0 right-0 p-8 z-10 ${bg} opacity-0
                              group-hover:opacity-100 transition-opacity duration-300`}
                                >
                                    <Image
                                        width={300}
                                        height={300}
                                        src={event.thumbnail}
                                        alt={event.title}
                                        className={imgBlend}
                                    />
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
}
