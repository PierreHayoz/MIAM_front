import Image from "next/image";
import { notFound } from "next/navigation";
import { getEvent } from "@/app/lib/events";

export const revalidate = 60; 

function formatDateRange(startDate, endDate) {
    if (!startDate) return null;
    const fmt = new Intl.DateTimeFormat("fr-CH", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        timeZone: "Europe/Zurich",
    });
    const s = fmt.format(new Date(startDate));
    if (!endDate || endDate === startDate) return s;
    const e = fmt.format(new Date(endDate));
    return `${s} → ${e}`;
}
function formatTimeRange(startTime, endTime) {
    if (!startTime && !endTime) return null;
    if (startTime && endTime) return `${startTime} – ${endTime}`;
    return startTime || endTime || null;
}

export default async function Page({ params }) {
    const { slug } = await params; // ✅ Next 15
    const event = await getEvent(slug);
    if (!event) return notFound();

    const dateLabel = formatDateRange(event.startDate, event.endDate);
    const timeLabel = formatTimeRange(event.startTime, event.endTime);

    return (
        <article className="px-4 grid grid-cols-4 gap-6">
            <div className="col-span-4 lg:col-span-1 md:sticky md:top-40">
                {event.categories?.length > 0 && (
                    <div className="flex gap-2 flex-wrap mb-3">
                        {event.categories.map((c, i) => (
                            <span key={i} className="text-xs px-2 py-0.5 rounded-full border">
                                {c}
                            </span>
                        ))}
                    </div>
                )}

                {(dateLabel || timeLabel) && (
                    <div className="flex gap-4">
                        <div className="flex gap-4  items-center">
                            {dateLabel && <span className="block">{dateLabel}</span>}
                            {timeLabel && <span className="block">{timeLabel}</span>}
                        </div>
                    </div>
                )}

                <h1 className="text-3xl mb-3">{event.title}</h1>

                {event.content && (
                    <div className="prose prose-invert max-w-none text-MIAMgrey">
                        <p>{event.content}</p>
                    </div>
                )}

                

                
            </div>
            {event.thumbnail && (
                    <Image
                        src={event.thumbnail}
                        alt={event.title}
                        width={1200}
                        height={800}
                        className="w-full col-span-2 mix-blend-darken h-auto mb-3 rounded grayscale contrast-[1000%] brightness-[100%] hover:grayscale-0 hover:contrast-100 hover:brightness-100 transition-all"
                        sizes="(min-width:1024px) 50vw, 100vw"
                    />
                )}
                {event.thumbnail && (
                    <Image
                        src={event.thumbnail}
                        alt={event.title}
                        width={1200}
                        height={800}
                        className="col-start-3 w-full col-span-2 mix-blend-darken h-auto mb-3 rounded grayscale contrast-[1000%] brightness-[100%] hover:grayscale-0 hover:contrast-100 hover:brightness-100 transition-all"
                        sizes="(min-width:1024px) 50vw, 100vw"
                    />
                )}
                {event.thumbnail && (
                    <Image
                        src={event.thumbnail}
                        alt={event.title}
                        width={1200}
                        height={800}
                        className="w-full col-start-2 col-span-2 mix-blend-darken h-auto mb-3 rounded grayscale contrast-[1000%] brightness-[100%] hover:grayscale-0 hover:contrast-100 hover:brightness-100 transition-all"
                        sizes="(min-width:1024px) 50vw, 100vw"
                    />
                )}
        </article>
    );
}

export async function generateStaticParams() {
    const { getSlugs } = await import("@/app/lib/events");
    const slugs = await getSlugs();
    return slugs.map((slug) => ({ slug }));
}
