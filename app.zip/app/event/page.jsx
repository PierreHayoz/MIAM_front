import CardsListServer from '../components/cards/CardsList';
import { localEvents } from '../lib/events';

export const dynamic = 'force-dynamic'

export default async function Page({ searchParams }) {
  const params = await searchParams; // ⬅️ important en Next 15
  return <CardsListServer events={localEvents} searchParams={params} />
}
