import React from 'react';
import IllustrationList from '../components/Illustrations/IllustrationList';
import Image from 'next/image';

const Page = () => {
    return (
        <div className="px-4">
            <button className="cursor-pointer w-fit h-fit relative px-3 py-1  group overflow-hidden">
                <div className="-z-10 bg-MIAMblack w-full h-full absolute top-0 left-0 group-hover:scale-100 scale-0 transition-all duration-500"></div>
                <div className="bg-MIAMwhite w-full h-full absolute group-hover:scale-0 scale-100 transition-all top-0 left-0 z-0 duration-500"></div>
                <div className="w-full h-full text-MIAMwhite z-10 mix-blend-difference">Acheter un billet</div>
            </button>

            <IllustrationList />

            <div className="relative w-fit overflow-hidden group">
                <div className="absolute h-full bg-MIAMviolet w-full left-0 top-0 -z-1 group-hover:top-0"></div>
                <Image src="/image_treshold_1.jpg" width={300} height={300} className='mix-blend-darken hover:mix-blend-lighten transition-all invert' />
            </div>
        </div>
    );
}

export default Page;
