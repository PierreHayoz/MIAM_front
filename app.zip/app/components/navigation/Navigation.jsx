import React from 'react';

const Navigation = () => {
    return (
        <div className='w-full h-20 bg-white fixed top-0 z-50'>
            
        </div>
    );
}

export default Navigation;
