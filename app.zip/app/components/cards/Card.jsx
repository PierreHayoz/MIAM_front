"use client";
import Link from "next/link";
import Image from "next/image";
import { useMemo } from "react";

// Liste des classes hover possibles (littérales pour Tailwind)
const HOVER_BG_CLASSES = [
  "hover:bg-MIAMblack",
  "hover:bg-MIAMviolet",
  "hover:bg-MIAMtomato",
  "hover:bg-MIAMlime",
];

const Card = ({
  slug,
  title,
  thumbnail,
  startDate,
  endDate,
  startTime,
  endTime,
  description,
  categories = [],
}) => {
  // Helpers dates
  const formatDateRange = (s, e) => {
    if (!s) return null;
    const fmt = new Intl.DateTimeFormat("fr-CH", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      timeZone: "Europe/Zurich",
    });
    const start = fmt.format(new Date(s));
    if (!e || e === s) return start;
    const end = fmt.format(new Date(e));
    return `${start} → ${end}`;
  };
  const formatTimeRange = (s, e) => {
    if (!s && !e) return null;
    if (s && e) return `${s} – ${e}`;
    return s || e || null;
  };

  const dateLabel = formatDateRange(startDate, endDate);
  const timeLabel = formatTimeRange(startTime, endTime);

  // Couleur de fond au hover choisie aléatoirement (stable par montage)
  const hoverBgClass = useMemo(
    () => HOVER_BG_CLASSES[Math.floor(Math.random() * HOVER_BG_CLASSES.length)],
    []
  );

  // Styles dépendants de la couleur
  // Par défaut (violet/tomato/lime): texte noir au hover
  let hoverTextClass = "hover:text-MIAMblack";
  let imageHoverClass = "mix-blend-darken group-hover:invert duration-500"; // règle spéciale seulement pour black
  let categoryHoverClass = "group-hover:text-MIAMblack group-hover:border-MIAMblack";

  if (hoverBgClass === "hover:bg-MIAMblack") {
    hoverTextClass = "hover:text-MIAMwhite";
    imageHoverClass = "mix-blend-darken group-hover:mix-blend-lighten group-hover:invert ";
    categoryHoverClass = "group-hover:text-MIAMwhite group-hover:border-MIAMwhite";
  } else if (hoverBgClass === "hover:bg-MIAMlime") {
    // On précise quand même pour lime
    hoverTextClass = "hover:text-MIAMblack";
    categoryHoverClass = "group-hover:text-MIAMblack group-hover:border-MIAMblack";
  }

  return (
    <Link href={`/event/${slug}`} className="block">
      <article
        className={[
          "font-haas p-4 pb-8 group transition duration-500 cursor-pointer",
          "bg-transparent",     // base : transparent
          hoverBgClass,         // au survol : couleur choisie
          hoverTextClass,       // couleur du texte au survol
        ].join(" ")}
      >
        <h2 className="mb-2">{title}</h2>

        {thumbnail && (
          <Image
            src={thumbnail}
            width={800}
            height={800}
            alt={title}
            className={["transition duration-500", imageHoverClass].join(" ")}
            sizes="(min-width:1024px) 33vw, (min-width:768px) 50vw, 100vw"
          />
        )}

        {(dateLabel || timeLabel) && (
          <div className="flex justify-between w-full gap-2 mt-2">
            <span>{dateLabel}</span>
            {timeLabel && <span>{timeLabel}</span>}
          </div>
        )}

        {description && (
          <p className="leading-tight block pt-1 pb-4 line-clamp-3">
            {description}
          </p>
        )}

        {categories?.length > 0 && (
          <div className="flex gap-1 flex-wrap">
            {categories.map((c, i) => (
              <div
                key={i}
                className={[
                  "text-xs px-2 py-0.5 rounded-full border transition-colors duration-300",
                  "border-MIAMblack text-MIAMblack", // base
                  categoryHoverClass,                // au survol (noir => blanc)
                ].join(" ")}
              >
                {c}
              </div>
            ))}
          </div>
        )}
      </article>
    </Link>
  );
};

export default Card;
