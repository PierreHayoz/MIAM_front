
export default async function page () {
    return (
        <div>
            CONTACT PAGE
        </div>
    );
}

