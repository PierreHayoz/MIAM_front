import React from 'react';
import Paragraphs from '../components/paragraphs/Paragraphs';
import Image from 'next/image';

const Page = () => {
    return (
        <div className="grid grid-cols-4 px-4">
                <h2 className="col-span-4 md:col-span-1 text-3xl">
                    L'association
                </h2>
                <div className="col-span-4 md:col-span-2 pb-20">
                    <Paragraphs
                        title="MIAM – Machine Immersive et Artistique en Mouvement"
                        subtitle="Un test"
                        text="MIAM a pour vocation de promouvoir la création et la diffusion de musiques immersives, de soutenir les innovations technomédiatiques et d’accompagner les artistes désireux d’inspirer un public varié. Les formes que cela prend sont nombreuses : voyages sonores immersifs, concerts à acoustique augmentée, performances spatialisées, soirées d’écoute multicanales, workshops immersifs et résidences artistiques."
                    />
                </div>
                <Image src="/images/image_treshold_1.jpg" width={1920} height={1080} className='col-span-4 mix-blend-darken' />
            </div>
    );
}

export default Page;
