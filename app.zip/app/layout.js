// app/layout.jsx
import "./globals.css";
import { LayoutGroup } from "framer-motion";
import { haas } from "./fonts";
import Footer from "./components/footer/Footer";
import Nav from "./components/navigation/Nav";
import SmoothScrolling from "./components/scroll/SmoothScrolling";
import IllustrationList from "./components/Illustrations/IllustrationList";
import ScrollToTopLenis from "./components/scroll/ScrollToTopLenis";
import Navigation from "./components/navigation/Navigation";

export default function RootLayout({ children }) {
  return (
    <html lang="fr" className={haas.variable}>
      <body className="antialiased bg-MIAMwhite">
        <SmoothScrolling>
        <Navigation/>
        <IllustrationList />
      
          <ScrollToTopLenis />
          <main className="pt-40 ">
            {children}
          </main>
        </SmoothScrolling>
        <div className="h-screen"></div>
        <Footer />
      </body>
    </html>
  );
}
