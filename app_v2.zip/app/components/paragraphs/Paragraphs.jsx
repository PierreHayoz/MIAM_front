import React from 'react';

const Paragraphs = ({ title, text,type }) => {
    return (
        <div>
            <h2 className='text-xl text-MIAMblack'>{title}</h2>
            {text &&
                <p className='text-sm text-MIAMgrey pt-2'>{text}</p>
            }
            {type === "list" &&
                <div className="pt-2 text-MIAMgrey text-sm">
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                    <div className="grid grid-cols-2 justify-between border-b">
                        <div className="">Camille Dubois</div>
                        <div className="">Directrice artistique & cofondatrice</div>
                    </div>
                </div>
            }
        </div>
    );
}

export default Paragraphs;
