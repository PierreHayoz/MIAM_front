import React from 'react';

const MidParagraph = ({ text }) => {
    return (
        <div className="grid grid-cols-4 w-full">
            <h2 className=' text-2xl leading-6 col-span-2 col-start-2 py-40'>{text}</h2>
        </div>
    );
}

export default MidParagraph;
