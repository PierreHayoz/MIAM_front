"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useState } from "react";
import { motion, LayoutGroup } from "framer-motion";

const items = [
    { url: "/event", title: "Programme" },
    { url: "/association", title: "L'association" },
    { url: "/espace", title: "L'espace" },
    { url: "/glossaire", title: "Glossaire" },
    { url: "/contact", title: "Contact" },
];

export default function Nav() {
    const pathname = usePathname();
    const [hovered, setHovered] = useState(null);

    const isActive = (url) =>
        pathname === url || pathname.startsWith(url + "/");
    const currentUrl = hovered ?? items.find((it) => isActive(it.url))?.url ?? null;

    return (
        <motion.div
            layoutRoot
            className="w-full fixed top-0 left-0 flex justify-center items-center py-4 z-[100]"
            initial={false}
        >
            <LayoutGroup id="nav" initial={false}>
                <ul
                    className="bg-MIAMviolet/10 backdrop-blur-xl flex gap-1 p-1 rounded-full"
                    onMouseLeave={() => setHovered(null)}
                >
                    {items.map((item) => {
                        const active = isActive(item.url);
                        const current = currentUrl === item.url;

                        return (
                            <li key={item.url} className="relative">
                                {current && (
                                    <motion.div
                                    initial={false}
                                        layoutId="nav-pill"
                                        className="absolute top-0 left-0 inset-0 rounded-full -z-10 bg-MIAMblack"
                                    />
                                )}
                                <Link
                                    href={item.url}
                                    onMouseEnter={() => setHovered(item.url)}
                                    onFocus={() => setHovered(item.url)}
                                    onBlur={() => setHovered(null)}
                                    className={`inline-flex h-10 items-center px-3 leading-none rounded-full outline-none transition-colors ${current ? "text-white" : "hover:bg-MIAMblack/10"
                                        }`}
                                    aria-current={active ? "page" : undefined}
                                >
                                    {item.title}
                                </Link>
                            </li>
                        );
                    })}
                </ul>
            </LayoutGroup>
        </motion.div>
    );
}
