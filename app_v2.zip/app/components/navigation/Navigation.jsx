'use client';
import dynamic from 'next/dynamic';

// Charge le composant de navigation « riche » (animations Framer Motion, etc.)
// en client-side pour éviter tout clignotement SSR et garder le style actuel.
const Nav = dynamic(() => import('./Nav'), { ssr: false });

export default function Navigation() {
  return <Nav />;
}