import Image from 'next/image';
import React from 'react';
import MidParagraph from '../components/paragraphs/MidParagraph';
import Paragraphs from '../components/paragraphs/Paragraphs';
import { getMembers } from '../lib/members';
import RevealList from '../components/reveal/RevealList';
import clsx from 'clsx';

export const metadata = {
    title: "Association — MIAM",
    description: "Équipe et membres de l'association.",
};


function initials(name = "?") {
    return name
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((s) => s[0]?.toUpperCase())
        .join("");
}

export default async function Page() {
    const members = await getMembers();
    return (
        <>
            <div className="grid grid-cols-4 px-4">
                <h2 className="text-3xl">
                    L'association
                </h2>
                <div className="col-span-2 pb-20">
                    <Paragraphs
                        title="MIAM – Machine Immersive et Artistique en Mouvement"
                        subtitle="Un test"
                        text="MIAM a pour vocation de promouvoir la création et la diffusion de musiques immersives, de soutenir les innovations technomédiatiques et d’accompagner les artistes désireux d’inspirer un public varié. Les formes que cela prend sont nombreuses : voyages sonores immersifs, concerts à acoustique augmentée, performances spatialisées, soirées d’écoute multicanales, workshops immersifs et résidences artistiques."
                    />
                </div>
                <Image src="/image_1.jpg" width={1920} height={1080} className='col-span-4' />
            </div>
            <MidParagraph text="Nous unissons artistes, ingénieurs, institutions culturelles, festivals, laboratoires et écoles pour imaginer des expériences sonores qui repoussent les limites de l’écoute." />
            <div className="grid-cols-4 grid">
                <div className="col-span-2 col-start-2">
                    <Paragraphs title="Notre vision" text="Machine Immersive et Artistique en Mouvement – imagine un monde où l’écoute devient un langage universel, capable de traverser les cultures, les âges et les sensibilités.Nous croyons que le son immersif est plus qu’une technologie : c’est une expérience humaine, une porte ouverte sur l’imaginaire, un espace où chacun peut trouver sa place.
Inclusifs par essence, nous veillons à ce que nos projets soient accessibles à toutes et tous, indépendamment des origines, des parcours ou des capacités physiques. MIAM est un espace où la diversité est une force, où chaque voix compte et où l’on croit au pouvoir du collectif pour créer de la beauté.
Pour nous, l’avenir de l’art sonore se construit dans la rencontre : entre artistes et publics, entre disciplines et savoir-faire, entre l’intime et le spectaculaire. C’est cette rencontre que nous cultivons, patiemment, passionnément, en mouvement."/>
                </div>
            </div>
            <div className="grid-cols-4 grid">
                <div className="col-span-2 col-start-2">
                    <RevealList
                    items={members}
                    getKey={(m) => m.id ?? m.name}
                    getTitle={(m) => m.name}
                    getDescription={(m) => m.role}
                    variant="avatar"
                    getThumbnail={(m) => m.photo}
                    // Révélation enrichie : avatar + nom + rôle (garde le look Archives)
                    renderReveal={(m, { blendClass }) => (
                        <div className="flex items-center gap-4">
                            {m.photo ? (
                                <Image
                                    width={100}
                                    height={100}
                                    src={m.photo}
                                    alt={m.name}
                                    className={clsx("rounded-full", blendClass)}
                                />
                            ) : (
                                <div className="w-16 h-16 rounded-full flex items-center justify-center text-white border border-white/30">
                                    {initials(m.name)}
                                </div>
                            )}


                            <div className="text-white max-w-xs leading-tight">
                                <div className="font-medium">{m.name}</div>
                                {m.role && <div className="opacity-80">{m.role}</div>}
                            </div>
                        </div>
                    )}
                />
                </div>
                
            </div>
            <div className="grid-cols-4 grid">
                <div className="col-span-2 col-start-2">
                    <Paragraphs title="Nos collaborations" text="Chaque projet est une aventure collective. Nous unissons artistes, ingénieurs, institutions culturelles, festivals, laboratoires et écoles pour imaginer des expériences sonores qui repoussent les limites de l’écoute.Inclusifs et ouverts, nous voyons chaque collaboration comme une co-création, où les savoir-faire se croisent pour donner vie à des œuvres uniques." />
                </div>
            </div>
            <div className="grid-cols-4 grid">
                <div className="col-span-2 col-start-2">
                    <Paragraphs title="Nos partenaires" text="MIAM s’entoure de partenaires visionnaires qui partagent notre passion pour l’art immersif et l’innovation sonore.
Festivals, institutions culturelles, entreprises technologiques, laboratoires de recherche et écoles d’art participent à la conception et à la diffusion de nos projets.Chacun, à sa manière, contribue à repousser les frontières de l’écoute, en apportant savoir-faire, ressources et ouverture sur de nouveaux publics.

Un immense merci à toutes celles et ceux qui nous accompagnent et rendent possible cette aventure : grâce à vous, nous pouvons rêver plus grand et faire vibrer l’écoute comme jamais." />
                </div>
            </div>
        </>
    );
}

