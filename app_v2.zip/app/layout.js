// app/layout.jsx
import "./globals.css";
import { haas } from "./fonts";
import Footer from "./components/footer/Footer";
import SmoothScrolling from "./components/scroll/SmoothScrolling";
import dynamic from 'next/dynamic';
const IllustrationList = dynamic(() => import('./components/Illustrations/IllustrationList'));
import ScrollToTopLenis from "./components/scroll/ScrollToTopLenis";
import Navigation from "./components/navigation/Navigation";

export const metadata = {
  metadataBase: new URL('https://miam.example'),
  title: {
    default: "MIAM — Machine Immersive et Artistique en Mouvement",
    template: "%s — MIAM"
  },
  description: "Espace dédié aux arts sonores et à l’écoute immersive à Fribourg.",
  openGraph: {
    type: "website",
    locale: "fr_CH",
    url: "https://miam.example",
    siteName: "MIAM"
  }
};
export default function RootLayout({ children }) {
  return (
    <html lang="fr" className={haas.variable}>
      <body className="antialiased bg-MIAMwhite">
        <SmoothScrolling>
          <Navigation />
          <IllustrationList />
          <ScrollToTopLenis />
          <main className="pt-40 ">
            {children}
          </main>
        </SmoothScrolling>
        <Footer />
      </body>
    </html>
  );
}