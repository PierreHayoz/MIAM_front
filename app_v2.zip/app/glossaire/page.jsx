import RevealList from "../components/reveal/RevealList";
import { getGlossary } from "../lib/glossary";


export const metadata = {
  title: "Glossaire — MIAM",
  description: "Termes autour du son 3D, de l’électroacoustique et des arts spatiaux.",
};


export default async function Page() {
  const terms = await getGlossary();


  return (
    <section>
      <div className="grid grid-cols-4 px-4 gap-8">
        <h2 className="text-3xl">Glossaire</h2>
        <div className="col-span-2">
          <h3 className="text-xl">Ressources</h3>
          <RevealList
            items={terms}
            getKey={(t) => t.slug}
            getTitle={(t) => t.term}
            variant="text"
            getDescription={(t) => t.definition}
            // Options conservant le look Archives
            revealSide="right"
            arrow={
              true}
          /></div>
          <div className="col-span-2 col-start-2">
          <h3 className="text-xl">Technologies</h3>
          <RevealList
            items={terms}
            getKey={(t) => t.slug}
            getTitle={(t) => t.term}
            variant="text"
            getDescription={(t) => t.definition}
            // Options conservant le look Archives
            revealSide="right"
            arrow={
              true}
          /></div>
      </div>
    </section>
  );
}