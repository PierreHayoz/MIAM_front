import RevealList from "../components/reveal/RevealList";
import { getEvents } from "../lib/events"; // ta source existante
import { splitEventsByTime, groupByYear, eventKey, eventTitle, eventHref, eventThumb, isPastEvent } from "../lib/events-utils";


// ⚠️ Pour que la page se mette à jour automatiquement (que les événements
// "passent" en archives tout seuls), on régénère la page périodiquement.
// Choisis une fréquence adaptée (ici : toutes les heures).
export const revalidate = 3600; // ISR Next.js — 1h


export const metadata = {
    title: "Archives — MIAM",
    description: "Tous les événements passés, regroupés par année.",
};


export default async function Page() {
    const events = await getEvents();
    const { past } = splitEventsByTime(events);
    const byYear = groupByYear(past, "end");
    const years = Object.keys(byYear).filter(Boolean).sort((a, b) => Number(b) - Number(a));


    return (
        <section>
            <div className="grid grid-cols-4 px-4 gap-y-6">
                <h2 className="text-3xl">Archives</h2>
                <div className="col-span-3 space-y-10">
                    {years.map((year) => (
                        <div key={year}>
                            <h3 className="text-xl mb-2 opacity-70">{year}</h3>
                            <RevealList
                                items={byYear[year]}
                                getKey={eventKey}
                                getTitle={eventTitle}
                                getHref={eventHref}
                                variant="image"
                                getThumbnail={eventThumb}
                            />
                        </div>
                    ))}


                    {/* Cas sans événements */}
                    {years.length === 0 && (
                        <div className="text-sm opacity-70">Aucun événement passé pour le moment.</div>
                    )}
                </div>
            </div>
        </section>
    );
}